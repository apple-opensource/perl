/* Apollo's <netinet/in.h> isn't protected against multiple inclusion. */

#ifndef _NETINET_IN_INCLUDED
#define _NETINET_IN_INCLUDED

#include "/bsd4.3/usr/include/netinet/in.h"

#endif /* _NETINET_IN_INCLUDED */
