/* Would contain C code to generate Perl constants if not using cFile.pc */
