#   Spider Boardman  <spider@Orb.Nashua.NH.US>
$self->{LIBS} = [''];
